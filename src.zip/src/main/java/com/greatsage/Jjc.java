package com.greatsage;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;

/** Ponte por reflexao com as variaveis de jogador do Jujutsu Craft (sem dependencia de compilacao). */
public final class Jjc {
    private static Capability<?> CAP;
    private static boolean tried = false;

    private static boolean init() {
        if (tried) return CAP != null;
        tried = true;
        try {
            Class<?> c = Class.forName("net.mcreator.jujutsucraft.network.JujutsucraftModVariables");
            CAP = (Capability<?>) c.getField("PLAYER_VARIABLES_CAPABILITY").get(null);
        } catch (Throwable t) {
            GreatSageMod.LOGGER.error("Jujutsu Craft nao encontrado ou incompativel", t);
        }
        return CAP != null;
    }

    private static Object vars(Player p) {
        if (!init()) return null;
        return p.getCapability(CAP).orElse(null);
    }

    /** Aplica o golpe: o Jujutsu Craft passa a tratar como golpe selecionado (tecla R usa, HUD dele mostra). */
    public static boolean apply(Player p, GSData d, Catalog.Move m) {
        Object v = vars(p);
        if (v == null) return false;
        try {
            Class<?> k = v.getClass();
            if (!d.hasOrig) {
                d.origSecond = k.getField("SecondTechnique").getBoolean(v);
                d.origTech = k.getField("PlayerCurseTechnique").getDouble(v);
                d.origSel = k.getField("PlayerSelectCurseTechnique").getDouble(v);
                d.origCost = k.getField("PlayerSelectCurseTechniqueCost").getDouble(v);
                Object n = k.getField("PlayerSelectCurseTechniqueName").get(v);
                d.origName = n == null ? "" : n.toString();
                d.hasOrig = true;
            }
            k.getField("SecondTechnique").setBoolean(v, false);
            k.getField("PlayerCurseTechnique").setDouble(v, m.tech());
            k.getField("PlayerSelectCurseTechnique").setDouble(v, m.idx());
            k.getField("PlayerSelectCurseTechniqueCost").setDouble(v, m.cost());
            k.getField("PlayerSelectCurseTechniqueName").set(v, m.name());
            sync(v, p);
            return true;
        } catch (Throwable t) {
            GreatSageMod.LOGGER.error("Falha ao aplicar golpe", t);
            return false;
        }
    }

    public static void restore(Player p, GSData d) {
        if (!d.hasOrig) return;
        Object v = vars(p);
        if (v == null) return;
        try {
            Class<?> k = v.getClass();
            k.getField("SecondTechnique").setBoolean(v, d.origSecond);
            k.getField("PlayerCurseTechnique").setDouble(v, d.origTech);
            k.getField("PlayerSelectCurseTechnique").setDouble(v, d.origSel);
            k.getField("PlayerSelectCurseTechniqueCost").setDouble(v, d.origCost);
            k.getField("PlayerSelectCurseTechniqueName").set(v, d.origName);
            sync(v, p);
        } catch (Throwable t) {
            GreatSageMod.LOGGER.error("Falha ao restaurar tecnica", t);
        }
        d.hasOrig = false;
        d.active = "";
    }

    private static void sync(Object v, Player p) throws Exception {
        v.getClass().getMethod("syncPlayerVariables", Entity.class).invoke(v, p);
    }
}

package com.greatsage;

import com.greatsage.net.Net;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

@Mod(GreatSageMod.MOD_ID)
public class GreatSageMod {
    public static final String MOD_ID = "greatsage";
    public static final Logger LOGGER = LogUtils.getLogger();

    public GreatSageMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, GSConfig.SPEC);
        Net.register();
        Catalog.load();
    }
}

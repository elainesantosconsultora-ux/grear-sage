package com.greatsage;

import com.greatsage.net.Net;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = GreatSageMod.MOD_ID)
public class ServerEvents {

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide) return;
        Entity src = e.getSource().getEntity();
        if (!(src instanceof ServerPlayer p)) return;
        if (victim.getPersistentData().getBoolean("greatsage_absorbed")) return; // sem absorcao dupla
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(victim.getType());
        if (id == null || !id.getNamespace().equals("jujutsucraft")) return;
        Catalog.Char c = Catalog.byEntity(id.getPath());
        if (c == null) return;

        GSData d = GSData.of(p);
        if (GSConfig.REQUIRE_RIMURU.get() && !d.rimuru) return;
        victim.getPersistentData().putBoolean("greatsage_absorbed", true);

        int added = 0;
        d.chars.add(c.id());
        for (Catalog.Move m : c.moves()) if (d.moves.add(m.key())) added++;
        if (added == 0) return;
        d.save(p);
        Net.sync(p);
        p.sendSystemMessage(Component.literal("[Grande Sabio] Absorvido: " + c.name() + " (" + added + " tecnicas)"));
    }

    private static void reapply(ServerPlayer p) {
        GSData d = GSData.of(p);
        if (!d.active.isEmpty()) {
            Catalog.Move m = Catalog.move(d.active);
            if (m != null) Jjc.apply(p, d, m);
        }
        Net.sync(p);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) reapply(p);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) reapply(p);
    }
}

package com.greatsage;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Dados do Grande Sabio de um jogador. Salvos em PlayerPersisted (sobrevivem a morte e relogar). */
public final class GSData {
    private static final String ROOT = "greatsage";

    public boolean rimuru = false;
    public final Set<String> chars = new LinkedHashSet<>();
    public final Set<String> moves = new LinkedHashSet<>();
    public final List<String> equipped = new ArrayList<>();
    public int cursor = 0;
    public String active = "";
    // Backup da tecnica original do Jujutsu Craft, para restaurar
    public boolean hasOrig = false;
    public double origTech, origSel, origCost;
    public boolean origSecond;
    public String origName = "";

    public static GSData of(Player p) {
        CompoundTag persist = p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        return fromTag(persist.getCompound(ROOT));
    }

    public void save(Player p) {
        CompoundTag pd = p.getPersistentData();
        CompoundTag persist = pd.getCompound(Player.PERSISTED_NBT_TAG);
        persist.put(ROOT, toTag());
        pd.put(Player.PERSISTED_NBT_TAG, persist);
    }

    public CompoundTag toTag() {
        CompoundTag t = new CompoundTag();
        t.putBoolean("rimuru", rimuru);
        t.put("chars", list(chars));
        t.put("moves", list(moves));
        t.put("equipped", list(equipped));
        t.putInt("cursor", cursor);
        t.putString("active", active);
        t.putBoolean("hasOrig", hasOrig);
        t.putDouble("origTech", origTech);
        t.putDouble("origSel", origSel);
        t.putDouble("origCost", origCost);
        t.putBoolean("origSecond", origSecond);
        t.putString("origName", origName);
        return t;
    }

    public static GSData fromTag(CompoundTag t) {
        GSData d = new GSData();
        d.rimuru = t.getBoolean("rimuru");
        read(t.getList("chars", Tag.TAG_STRING), d.chars);
        read(t.getList("moves", Tag.TAG_STRING), d.moves);
        read(t.getList("equipped", Tag.TAG_STRING), d.equipped);
        d.cursor = t.getInt("cursor");
        d.active = t.getString("active");
        d.hasOrig = t.getBoolean("hasOrig");
        d.origTech = t.getDouble("origTech");
        d.origSel = t.getDouble("origSel");
        d.origCost = t.getDouble("origCost");
        d.origSecond = t.getBoolean("origSecond");
        d.origName = t.getString("origName");
        return d;
    }

    private static ListTag list(Iterable<String> src) {
        ListTag l = new ListTag();
        for (String s : src) l.add(StringTag.valueOf(s));
        return l;
    }
    private static void read(ListTag l, java.util.Collection<String> dst) {
        for (int i = 0; i < l.size(); i++) dst.add(l.getString(i));
    }
}

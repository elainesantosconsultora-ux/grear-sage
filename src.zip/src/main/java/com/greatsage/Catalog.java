package com.greatsage;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Catalogo de personagens e golpes do Jujutsu Craft (extraido do JAR ver50.1). */
public final class Catalog {
    public record Move(String key, int tech, int idx, String name, double cost, String charId) {}
    public record Char(String id, String name, int tech, List<String> entities, List<Move> moves) {}

    private static final Map<String, Char> BY_ID = new LinkedHashMap<>();
    private static final Map<String, Char> BY_ENTITY = new HashMap<>();
    private static final Map<String, Move> MOVES = new HashMap<>();
    private static boolean loaded = false;

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        try (InputStream in = Catalog.class.getResourceAsStream("/data/greatsage/characters.json")) {
            if (in == null) { GreatSageMod.LOGGER.error("characters.json nao encontrado"); return; }
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            for (JsonElement ce : root.getAsJsonArray("characters")) {
                JsonObject co = ce.getAsJsonObject();
                String id = co.get("id").getAsString();
                int tech = co.get("tech").getAsInt();
                List<String> ents = new ArrayList<>();
                for (JsonElement e : co.getAsJsonArray("entities")) ents.add(e.getAsString());
                List<Move> moves = new ArrayList<>();
                JsonArray ma = co.getAsJsonArray("moves");
                for (JsonElement me : ma) {
                    JsonObject mo = me.getAsJsonObject();
                    int idx = mo.get("idx").getAsInt();
                    Move m = new Move(tech + ":" + idx, tech, idx, mo.get("name").getAsString(),
                            mo.get("cost").getAsDouble(), id);
                    moves.add(m);
                    MOVES.put(m.key(), m);
                }
                Char c = new Char(id, co.get("name").getAsString(), tech, ents, moves);
                BY_ID.put(id, c);
                for (String e : ents) BY_ENTITY.put(e, c);
            }
        } catch (Exception ex) {
            GreatSageMod.LOGGER.error("Falha ao ler characters.json", ex);
        }
    }
    public static Char byEntity(String path) { return BY_ENTITY.get(path); }
    public static Char byId(String id) { return BY_ID.get(id); }
    public static Move move(String key) { return MOVES.get(key); }
}

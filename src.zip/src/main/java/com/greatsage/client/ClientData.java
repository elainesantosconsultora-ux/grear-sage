package com.greatsage.client;

import com.greatsage.GSData;
import net.minecraft.nbt.CompoundTag;

public final class ClientData {
    public static GSData data = new GSData();
    public static void set(CompoundTag t) { data = GSData.fromTag(t); }
    private ClientData() {}
}

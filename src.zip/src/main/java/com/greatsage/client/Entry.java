package com.greatsage.client;

public record Entry(String id, String name, Kind kind, String source, String info) {
    public enum Kind { RIMURU, CHARACTER, TECHNIQUE }
}

package com.greatsage.net;

import com.greatsage.Catalog;
import com.greatsage.GSConfig;
import com.greatsage.GSData;
import com.greatsage.Jjc;
import com.greatsage.client.ClientData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation("greatsage", "main"), () -> V, V::equals, V::equals);

    public static final int TOGGLE_RIMURU = 0, EQUIP = 1, LOADOUT = 2, CYCLE = 3, RESTORE = 4, CHAR = 5;

    public static void register() {
        int i = 0;
        CH.registerMessage(i++, SyncMsg.class, SyncMsg::enc, SyncMsg::dec, SyncMsg::handle);
        CH.registerMessage(i++, ActionMsg.class, ActionMsg::enc, ActionMsg::dec, ActionMsg::handle);
    }

    public static void sync(ServerPlayer p) {
        CH.send(PacketDistributor.PLAYER.with(() -> p), new SyncMsg(GSData.of(p).toTag()));
    }

    public static final class SyncMsg {
        final CompoundTag tag;
        public SyncMsg(CompoundTag tag) { this.tag = tag; }
        static void enc(SyncMsg m, FriendlyByteBuf b) { b.writeNbt(m.tag); }
        static SyncMsg dec(FriendlyByteBuf b) { CompoundTag t = b.readNbt(); return new SyncMsg(t == null ? new CompoundTag() : t); }
        static void handle(SyncMsg m, Supplier<NetworkEvent.Context> c) {
            NetworkEvent.Context ctx = c.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientData.set(m.tag)));
            ctx.setPacketHandled(true);
        }
    }

    public static final class ActionMsg {
        final int type; final String arg;
        public ActionMsg(int type, String arg) { this.type = type; this.arg = arg; }
        static void enc(ActionMsg m, FriendlyByteBuf b) { b.writeInt(m.type); b.writeUtf(m.arg, 64); }
        static ActionMsg dec(FriendlyByteBuf b) { return new ActionMsg(b.readInt(), b.readUtf(64)); }
        static void handle(ActionMsg m, Supplier<NetworkEvent.Context> c) {
            NetworkEvent.Context ctx = c.get();
            ServerPlayer p = ctx.getSender();
            ctx.enqueueWork(() -> { if (p != null) act(p, m.type, m.arg); });
            ctx.setPacketHandled(true);
        }
    }

    private static boolean use(ServerPlayer p, GSData d, String key) {
        Catalog.Move mv = Catalog.move(key);
        if (mv == null || !d.moves.contains(key)) return false;
        if (!Jjc.apply(p, d, mv)) {
            p.sendSystemMessage(Component.literal("[Grande Sabio] Jujutsu Craft nao encontrado."));
            return false;
        }
        d.active = key;
        return true;
    }

    /** Toda a logica roda no servidor, com validacao. */
    static void act(ServerPlayer p, int type, String arg) {
        GSData d = GSData.of(p);
        switch (type) {
            case TOGGLE_RIMURU -> {
                d.rimuru = !d.rimuru;
                p.sendSystemMessage(Component.literal("[Grande Sabio] Rimuru Tempest " + (d.rimuru ? "selecionado." : "desselecionado.")));
            }
            case EQUIP -> {
                if (!use(p, d, arg)) return;
                if (!d.equipped.contains(arg) && d.equipped.size() < GSConfig.MAX_SLOTS.get()) d.equipped.add(arg);
                d.cursor = Math.max(0, d.equipped.indexOf(arg));
            }
            case LOADOUT -> {
                if (!d.moves.contains(arg)) return;
                if (!d.equipped.remove(arg)) {
                    if (d.equipped.size() >= GSConfig.MAX_SLOTS.get()) {
                        p.sendSystemMessage(Component.literal("[Grande Sabio] Loadout cheio."));
                        return;
                    }
                    d.equipped.add(arg);
                }
                if (d.cursor >= d.equipped.size()) d.cursor = 0;
            }
            case CYCLE -> {
                if (d.equipped.isEmpty()) return;
                d.cursor = (d.cursor + 1) % d.equipped.size();
                if (!use(p, d, d.equipped.get(d.cursor))) return;
            }
            case CHAR -> {
                Catalog.Char c = Catalog.byId(arg);
                if (c == null || !d.chars.contains(arg)) return;
                List<String> keys = new ArrayList<>();
                for (Catalog.Move m : c.moves()) if (d.moves.contains(m.key())) keys.add(m.key());
                if (keys.isEmpty()) return;
                if (d.equipped.containsAll(keys)) {
                    d.equipped.removeAll(keys);
                    if (d.cursor >= d.equipped.size()) d.cursor = 0;
                } else {
                    int max = GSConfig.MAX_SLOTS.get();
                    for (String k : keys) if (!d.equipped.contains(k) && d.equipped.size() < max) d.equipped.add(k);
                    String first = keys.get(0);
                    if (d.equipped.contains(first)) {
                        if (!use(p, d, first)) return;
                        d.cursor = d.equipped.indexOf(first);
                    }
                }
            }
            case RESTORE -> {
                Jjc.restore(p, d);
                p.sendSystemMessage(Component.literal("[Grande Sabio] Tecnica original restaurada."));
            }
            default -> { return; }
        }
        d.save(p);
        sync(p);
    }
}

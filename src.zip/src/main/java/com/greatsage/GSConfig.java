package com.greatsage;

import net.minecraftforge.common.ForgeConfigSpec;

public final class GSConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_RIMURU;
    public static final ForgeConfigSpec.IntValue MAX_SLOTS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        REQUIRE_RIMURU = b.comment("Exige Rimuru Tempest selecionado no Grande Sabio para absorver.")
                .define("requireRimuruSelected", true);
        MAX_SLOTS = b.comment("Numero maximo de golpes no loadout (troca rapida).")
                .defineInRange("maxLoadoutSlots", 30, 1, 100);
        SPEC = b.build();
    }
    private GSConfig() {}
}
